package com.cap.service.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/HelloWorld-API")
@Api(value = "HelloWorldApi", description = "API exposed for Hello World")
public class HelloWorldController {

	@ApiOperation(value = "Greeting with Args")
	@RequestMapping(value = "/GreetingArg/{Name}", method = RequestMethod.GET)
	public String GreetingArg(@PathVariable String Name) {

		String message="Good Evening::::" + Name;
		
			return  "GreetingArg API Response :: \n" + message;
		
	}

	
}
