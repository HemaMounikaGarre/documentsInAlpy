import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-menuitems',
  templateUrl: './menuitems.component.html',
  styleUrls: ['./menuitems.component.css']
})
export class MenuitemsComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }
/* OnClickPost()
{
  this.router.navigate(['./postpage']);
}
OnClickDelete()
{
  this.router.navigate(['./deletepage']);
}
OnClickSearch()
{
  this.router.navigate(['./searchpage']);
}
 */
}
