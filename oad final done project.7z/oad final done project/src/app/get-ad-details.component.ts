import { Component, OnInit } from '@angular/core';
import { OnlineService } from './service/online.service';

@Component({
  selector: 'app-get-ad-details',
  templateUrl: './get-ad-details.component.html',
  styleUrls: ['./get-ad-details.component.css']
})
export class GetAdDetailsComponent implements OnInit {
  samples:any[]=[];
  
  category:any;
  constructor(private service:OnlineService) { }

  ngOnInit() {
    this.category=localStorage.getItem("category");
    console.log("category"+this.category);
    this.service.searchAd(this.category).subscribe((data:any)=>{
      console.log(data);
      this.samples=data;
    })
  }

}
