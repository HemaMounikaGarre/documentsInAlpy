import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OnlineService } from './service/online.service';

@Component({
  selector: 'app-updateadd',
  templateUrl: './updateadd.component.html',
  styleUrls: ['./updateadd.component.css']
})
export class UpdateaddComponent implements OnInit {
  samples:any[]=[];
  Id:any;
  a:boolean=false;
  b:boolean=false;
  c:boolean=true;
  model:any;
  constructor(private service:OnlineService,private router:Router) { }

  ngOnInit() {
    
  }
  onSubmit(values:any){
    console.log(values);
    this.service.getById(values.uniId).subscribe((data:any)=>{
      console.log(data);
      this.samples=data;
    })
    this.c=false; 
    this.a=true;
  }

  /* onClickNext()
  {
    console.log("clicked");
  } */
  onClick(model:any)
  {
    console.log("only cno"+model);
    this.service.update(model).subscribe((data:any)=>{
      console.log(data);
      this.samples=data;
  
   // alert("updated successfully");
    })
    this.a=false;
    this.b=true;

  }
 }
