import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{FormsModule} from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegComponent } from './registration/reg.component';
import { from } from 'rxjs';
import { LoginComponent } from './registration/login.component';
import { PostingAdComponent } from './registration/posting-ad.component';
import{HttpClientModule} from '@angular/common/http';
import { MenuitemsComponent } from './menuitems.component';
import { DeleteAdComponent } from './delete-ad.component';
import { SearchAdComponent } from './search-ad.component';
import { GetAdDetailsComponent } from './get-ad-details.component';
import { UpdateaddComponent } from './updateadd.component';
import { GetAllComponent } from './get-all.component';
import { ReportAdComponent } from './report-ad.component';
import { AdminDeleteComponent } from './admin-delete.component';
import { UploadAdComponent } from './upload-ad/upload-ad.component';
import { HomeClickComponent } from './home-click.component';
import { RUHomeComponent } from './ruhome.component';
import { VHomeComponent } from './vhome.component';
import { VSearchComponent } from './vsearch.component';
import { AdminContactComponent } from './admin-contact.component';
import { AdminHomeComponent } from './admin-home.component';
import { ForgotpasswordComponent } from './forgotpassword.component';
import { DefaultComponent } from './default.component';
import {DataTableModule} from 'angular-6-datatable';
@NgModule({
  declarations: [
    AppComponent,
    RegComponent,
    LoginComponent,
    PostingAdComponent,
    MenuitemsComponent,
    DeleteAdComponent,
    SearchAdComponent,
    GetAdDetailsComponent,
    UpdateaddComponent,
    GetAllComponent,
    ReportAdComponent,
    AdminDeleteComponent,
    UploadAdComponent,
    HomeClickComponent,
    RUHomeComponent,
    VHomeComponent,
    VSearchComponent,
    AdminContactComponent,
    AdminHomeComponent,
    ForgotpasswordComponent,
    DefaultComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    DataTableModule
  ],                          
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
