package com.cg.oad.dto;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="reports")
public class Feedback {
private String uId;
private String description;
public Feedback() {
	// TODO Auto-generated constructor stub
}
public Feedback(String uId, String description) {
	super();
	this.uId = uId;
	this.description = description;
}
public String getuId() {
	return uId;
}
public void setuId(String uId) {
	this.uId = uId;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
@Override
public String toString() {
	return "Feedback [uId=" + uId + ", description=" + description + "]";
}

}
