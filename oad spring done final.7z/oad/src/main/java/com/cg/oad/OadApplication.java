package com.cg.oad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.cg.oad")
public class OadApplication {

	public static void main(String[] args) {
		SpringApplication.run(OadApplication.class, args);
		System.out.println("running succesfully");
		
	}

}
