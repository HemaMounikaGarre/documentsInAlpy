package com.cg.oad.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.oad.dao.AdDaoImpl;
import com.cg.oad.dto.AdDetails;
import com.cg.oad.dto.Feedback;
import com.cg.oad.dto.Registration;

@Service
public class AdSeviceImpl implements AdServiceI{
	
	@Autowired
	AdDaoImpl adDaoImpl;
	
	
	
	@Override
	public void register(Registration registration) {
		adDaoImpl.register(registration);
		
	}
	@Override
	public Boolean validate(String mail, String password) {
		return adDaoImpl.validate(mail, password);
	}
	
	
	
	
	@Override
	public void postAd(AdDetails adDetails) {
		adDaoImpl.postAd(adDetails);
		
	}
	@Override
	public List<AdDetails> getd(String name) {
		return adDaoImpl.getd(name);
	}


	
	@Override
	public void deleteAdd(String id) {
		// TODO Auto-generated method stub
		adDaoImpl.deleteAdd(id);
		
	}
	@Override
	public void update(AdDetails adDetails) {
		// TODO Auto-generated method stub
		adDaoImpl.update(adDetails);
	}
	@Override
	public List<AdDetails> GetAll() {
		// TODO Auto-generated method stub
		return adDaoImpl.GetAll();
	}
	
	@Override
	public void PostReport(String id, String desc) {
		// TODO Auto-generated method stub
		adDaoImpl.PostReport(id, desc);
	}
	@Override
	public AdDetails getById(String id) {
		// TODO Auto-generated method stub
		return adDaoImpl.getById(id);
	}
	
	@Override
	public Boolean ForgetPass(String mail,String password) {
		return adDaoImpl.ForgetPass(mail,password);
	} 
}
