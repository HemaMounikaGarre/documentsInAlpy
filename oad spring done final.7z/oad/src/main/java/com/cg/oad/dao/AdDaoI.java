package com.cg.oad.dao;

import java.util.List;

import com.cg.oad.dto.AdDetails;
import com.cg.oad.dto.Feedback;
import com.cg.oad.dto.Registration;

public interface AdDaoI {
	
	public void register(Registration registration);
	public Boolean validate(String mail, String password);
	public Boolean ForgetPass(String mail,String password);
	public void postAd(AdDetails adDetails);
	public List<AdDetails> getd(String name);
	public void update(AdDetails adDetails);
	void deleteAdd(String id);
	List<AdDetails> GetAll();
	public void PostReport(String id,String desc);
	public void insertReport(String id,String desc);
	public AdDetails getById(String id);
	
	
	
}
