package com.cg.oad.dao;

import java.util.ArrayList;
import java.util.Base64;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cg.oad.dto.AdDetails;
import com.cg.oad.dto.Feedback;
import com.cg.oad.dto.Registration;

@Repository
public class AdDaoImpl implements AdDaoI{

	@Autowired
	MongoTemplate mongoTemplate;
	
	
	
	
	
	
	@Override
	public void register(Registration registration) {
		String pwd=registration.getPassword();
		String s1=Base64.getEncoder().encodeToString(pwd.getBytes());
		registration.setPassword(s1);
		

		mongoTemplate.save(registration);
		
	}
	
	
	@Override
	public Boolean validate(String mail, String password) {
		List<Registration> userDetails=mongoTemplate.findAll(Registration.class);
		for (Registration registration : userDetails) {
			byte[] decodedBytes=Base64.getDecoder().decode(registration.getPassword());
			String decodedString=new String(decodedBytes);

System.out.println("decoded pass"+registration.getPassword());


//Base64.getDecoder().decode(registration.getPassword());

			if(registration.getEmailId().equals(mail)&& decodedString.equals(password))
				return true;
		
		}
		return false;
	}
	
	
	
	
	
	@Override
	public void postAd(AdDetails adDetails) {
		
		
		mongoTemplate.save(adDetails);
		
	}

	@Override
	public List<AdDetails> getd(String name) {
		List<AdDetails> details= mongoTemplate.findAll(AdDetails.class);
		List<AdDetails> result=new ArrayList<>();
		for (AdDetails adDetails : details) {
			if(adDetails.getCategory().equalsIgnoreCase(name)||adDetails.getName().equalsIgnoreCase(name))
			{
				
				result.add(adDetails);
			}
			
		}
			
		return result;
	}
	
	@Override
	public Boolean ForgetPass(String mail,String password) {
		List<Registration> userDetails=mongoTemplate.findAll(Registration.class);
		for (Registration registration : userDetails) {
			if(registration.getEmailId().equals(mail))
			{
				String fpwd=registration.getPassword();
				String encoded=Base64.getEncoder().encodeToString(password.getBytes());
				registration.setPassword(encoded);
				//System.out.println(registration.getPassword());
				mongoTemplate.save(registration);
				return true;
			}
				
		
		}
		return false;
	} 

	
	
	@Override
	public void deleteAdd(String id) {
		List<AdDetails> details=mongoTemplate.findAll(AdDetails.class);
		for (AdDetails adDetails2 : details) {
			if(adDetails2.getGenUniqId().equals(id))
		
		
		mongoTemplate.remove(adDetails2);
		}
		
	}


	@Override
	public void update(AdDetails adDetails) {
		// TODO Auto-generated method stub
		AdDetails object=mongoTemplate.findById(adDetails.getGenUniqId(),AdDetails.class);
		deleteAdd(adDetails.getGenUniqId());
		object.setCategory(adDetails.getCategory());
		object.setContactNo(adDetails.getContactNo());
		object.setDescription(adDetails.getDescription());
		object.setEmailId(adDetails.getEmailId());
		object.setGenUniqId(adDetails.getGenUniqId());
		object.setName(adDetails.getName());
		object.setPrice(adDetails.getPrice());
		mongoTemplate.insert(object);
		
		
	}


	@Override
	public List<AdDetails> GetAll() {
		// TODO Auto-generated method stub
		return mongoTemplate.findAll(AdDetails.class);
	}


	


	


	@Override
	public void PostReport(String id, String desc) {
		// TODO Auto-generated method stub
		List<AdDetails> result=mongoTemplate.findAll(AdDetails.class);
		insertReport(id, desc);
		
	}


	


	@Override
	public void insertReport(String id, String desc) {
		// TODO Auto-generated method stub
		Feedback fd=new Feedback();
		fd.setuId(id);
		fd.setDescription(desc);
		System.out.println("in dao"+fd);
		mongoTemplate.save(fd);
		
		
		
	}


	@Override
	public AdDetails getById(String id) {
		// TODO Auto-generated method stub
		List<AdDetails> details= mongoTemplate.findAll(AdDetails.class);
		AdDetails result=new AdDetails();
		
		for (AdDetails adDetails : details) {
			if(id.equals(adDetails.getGenUniqId()))
			{
				
				return adDetails;
			}
		}
			
		return result;
		
	}


	
	
	

	

	

}
