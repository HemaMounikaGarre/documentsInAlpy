package com.cg.oad.dto;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="user")
public class Registration {
  private String name;
  @Id
  private String emailId;
  private long contactNo;
  private String password;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public long getContactNo() {
	return contactNo;
}
public void setContactNo(long contactNo) {
	this.contactNo = contactNo;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
  public Registration() {
	// TODO Auto-generated constructor stub
}
public Registration(String name, String emailId, long  contactNo, String password) {
	super();
	this.name = name;
	this.emailId = emailId;
	this.contactNo = contactNo;
	this.password = password;
}
@Override
public String toString() {
	return "Registration [name=" + name + ", emailId=" + emailId + ", contactNo=" + contactNo + ", password=" + password
			+ "]";
}
}
