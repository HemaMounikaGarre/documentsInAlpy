import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AuthService } from '../shared/auth.service';
import { Router } from '@angular/router';

@Component({
    templateUrl:'./profilepage.html',
    styles:[`
        em{float:right;color:red}

    `]
})
export class ProfileComponent{
    profileForm: FormGroup
    firstName:FormControl
    lastName:FormControl


    constructor(private authService:AuthService,private router:Router){

    }
    ngOnInit(){
        this.firstName=new FormControl(this.authService.currentUser.firstName,
            [Validators.required,Validators.pattern('[a-zA-Z].*')])
        this.lastName=new FormControl(this.authService.currentUser.lastName,Validators.required)
        this.profileForm=new FormGroup({
            firstName:this.firstName,
            lastName:this.lastName
        })

    }

    save(formValues){
        //to hit the authservice and change the first name and last name
        this.authService.updateUser(formValues.firstName,formValues.lastName)
        //after saving the new details of the profile ....redirect the user to some route
        this.router.navigate(['home'])
    }
    //return true if it is valid and untouched
    validateFirstName(){
        return this.firstName.valid || this.firstName.untouched
    }

    //return true if it is valid and untouched
    validateLastName(){
        return this.lastName.valid || this.lastName.untouched
    }

}