import { Component } from '@angular/core';
import { AuthService } from '../shared/auth.service';
import { Router } from '@angular/router';

@Component({
    templateUrl:'./loginpage.html',
    styles:[
        `
            em{color:red;float:right}
        `
    ]
})
export class LoginComponent{

        constructor(private authService:AuthService,private router:Router){

        }

        login(formValues){
            //hit auth service and invoke authenticate()
            //navigate the user to some view
            this.authService.authenticate(formValues.userName,formValues.password)
            this.router.navigate(['home'])
            
        }
}