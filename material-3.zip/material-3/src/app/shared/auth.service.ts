import { IUser } from '../user/user.model';

export class AuthService{

    currentUser:IUser
    
    authenticate(uName:string,pwd:string){
        //going to hit the restful service and bring some addnl data of the user
        //the assumption all users are valid, the currentUser var will be empty if invalid user
        this.currentUser={
            id:1,
            userName:uName,
            firstName:'Prakash',
            lastName:'Shah'
        }
    }
    isAuthenticated(){
        return !!this.currentUser
    }

    updateUser(fName:string,lName:string){
        this.currentUser.firstName=fName
        this.currentUser.lastName=lName
        //hit the restful service and give this new value so that it gets updated in the data table

    }
}