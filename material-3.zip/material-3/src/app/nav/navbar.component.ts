import { Component } from '@angular/core';
import { AuthService } from '../shared/auth.service';

@Component({
    selector:'nav-bar',
    templateUrl:'./navbar.html'
})
export class NavBarComponent{
    constructor(private authServ:AuthService){

    }
}