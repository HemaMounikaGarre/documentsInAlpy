import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    templateUrl:'./createeventpage.html'
})
export class CreateEventComponent{
    constructor(private router:Router){

    }
    cancelMe(){
        this.router.navigate(['home'])
    }

    saveEvent(formValues){
        //take all the data and add this data to events
        //redirect the user to show all the events
        console.log(formValues)
    }
}