import { Component } from '@angular/core';
import { EventService } from '../shared/event.service';
import { IEvent } from '../shared/event.model';

@Component({
    selector:'event-list',
 
    template:`
            <div>
                <h1 [innerText]="eventtitle"></h1>
                <hr/>
                <div *ngFor="let xyz of events" class="col-md-5" >
                    <event-thumbnail [event]="xyz"></event-thumbnail>
                </div>
            </div>
    `
})
export class EventListComponent{

    eventtitle="Upcoming Angular Events"
    events:IEvent[]

    constructor(private es:EventService){

    }
    ngOnInit(){
        this.events=this.es.getEvents()
    }

}