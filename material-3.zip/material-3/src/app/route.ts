import {Routes} from '@angular/router'
import { EventListComponent } from './events/eventlist.component'
import { HomePageComponent } from './events/homepage.component'
import { EventDetailsComponent } from './events/eventdetails.component'
import { CreateEventComponent } from './events/createevent.component'

export const appRoutes:Routes=[
    {path:'events/create',component:CreateEventComponent},
    {path:'events',component:EventListComponent},
    {path:'events/:id',component:EventDetailsComponent},
    {path:'home',component:HomePageComponent},
    {path:'user',loadChildren:'src/app/user/user.module#UserModule'},
    {path:'',redirectTo:'home',pathMatch:'full'}   
]