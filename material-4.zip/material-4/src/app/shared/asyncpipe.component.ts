import { Component } from '@angular/core';

@Component({
    selector:'async-pipe',
    template:`
        <div>
            <h2>Demo on usage of async pipe</h2>
            <p>Output for City name will be shown after delay of 4 seconds {{city|async}}</p>
        </div>
    
    `
})
export class DemoComponent{
    city:Promise<any>

    ngOnInit(){
        this.city=this.getCity()
    }
    getCity(){
        //we want this function to execute asynchronously
        return new Promise((resolve,reject)=>{
            //code to invoke some service 
            //service will return flag
            //based on the flag we will return resovle or reject object
            setTimeout(()=>resolve('Mumbai'),4000)
        })
    }
}