import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name:'converttext'
    }
)
export class ConvertPipe implements PipeTransform{
        transform(input:number):string{
            switch(input){
                case 1: return 'Half Hour'
                case 2: return 'One hour'
                case 3: return 'Half Day'
                default: return 'Full Day'
            }
        }
}

