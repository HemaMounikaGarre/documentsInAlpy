import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { EventService } from '../shared/event.service';

@Component({
    templateUrl:'./createeventpage.html'
})
export class CreateEventComponent{
    constructor(private router:Router,private eventService:EventService){

    }
    cancelMe(){
        this.router.navigate(['home'])
    }

    saveEvent(formValues){
        //take all the data and add this data to events
        this.eventService.addEvent(formValues)
        //redirect the user to show all the events
        this.router.navigate(['events'])        
    }
}