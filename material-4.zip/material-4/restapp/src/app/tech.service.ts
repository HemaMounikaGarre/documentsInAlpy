import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ITech } from './tech.model';

@Injectable({
    providedIn:'root'
})
export class TechService{
    endpoint="https://www.techiediaries.com/api/data.json"

    constructor(private httpClient:HttpClient){

    }

    //this func will execute asynchronously
    getTechnologies():Observable<ITech[]>{
        return <Observable<ITech[]>>this.httpClient.get(this.endpoint)
    }
}