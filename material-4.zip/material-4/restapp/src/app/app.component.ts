import { Component } from '@angular/core';
import { TechService } from './tech.service';
import { ITech } from './tech.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  
})
export class AppComponent {
    technologies:Array<ITech>

    constructor(private techServ:TechService){

    }
    ngOnInit(){
      this.techServ.getTechnologies().subscribe((data:Array<ITech>)=>this.technologies=data)
    }

}
