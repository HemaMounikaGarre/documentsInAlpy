export interface ITech{
    name:string,
    description:string
    url:string
}