import {Routes} from '@angular/router'
import { EventListComponent } from './events/eventlist.component'
import { HomePageComponent } from './events/homepage.component'
import { EventDetailsComponent } from './events/eventdetails.component'

export const appRoutes:Routes=[
    {path:'events',component:EventListComponent},
    {path:'events/:id',component:EventDetailsComponent},
    {path:'home',component:HomePageComponent},
    {path:'',redirectTo:'home',pathMatch:'full'}   
]