import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { EventListComponent } from './events/eventlist.component';
import { EventThumbnailComponent } from './events/eventthumbnail.component';
import {FormsModule} from '@angular/forms'
import { NavBarComponent } from './nav/navbar.component';
import { EventService } from './shared/event.service';
import { HomePageComponent } from './events/homepage.component';
import { RouterModule } from '@angular/router';
import { appRoutes } from './route';
import { EventDetailsComponent } from './events/eventdetails.component';

@NgModule({
  declarations: [
    AppComponent,EventListComponent,EventThumbnailComponent,NavBarComponent,HomePageComponent,
    EventDetailsComponent
  ],
  imports: [
    BrowserModule,FormsModule,RouterModule.forRoot(appRoutes)
  ],
  providers: [EventService],
  bootstrap: [AppComponent]
})
export class AppModule { }
