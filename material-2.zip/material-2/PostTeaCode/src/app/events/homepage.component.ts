import { Component } from '@angular/core';

@Component({
    selector:'home-page',
    template:`
            <div>
                <h1>Home Page under construction</h1>
            </div>
    
    `
})
export class HomePageComponent{

}