import { Component } from '@angular/core';
import { EventService } from '../shared/event.service';
import { ActivatedRoute } from '@angular/router';

@Component({
    templateUrl:'./eventdet.html'
})
export class EventDetailsComponent{
  
    event:any

    constructor(private es:EventService,private actRoute:ActivatedRoute){

    }

    ngOnInit(){
        this.event=this.es.getEvent(+this.actRoute.snapshot.params['id'])
    }
}