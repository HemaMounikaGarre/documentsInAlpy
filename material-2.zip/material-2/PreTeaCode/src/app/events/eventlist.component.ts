import { Component } from '@angular/core';

@Component({
    selector:'event-list',
 
    template:`
            <div>
                <h1 [innerText]="eventtitle"></h1>
                <hr/>
                <event-thumbnail #myvar (myevent)="receiveData($event)" [event]="event"></event-thumbnail>
                <br/>
                Last Name <input type="text" [(ngModel)]='userlastname' />
                <br/>
                <span [innerText]="userlastname"></span>

                <br/>
                <button (click)="myvar.saveme()">InvokeSaveMe</button>
            </div>
    `
})
export class EventListComponent{

    userlastname='Agarwal'

    eventtitle="Upcoming Angular Events"

    event={
        id:1,
        name:'Angular Connect',
        date:'01/01/2021',
        time:'8:00 am',
        price: 566.50,
        location:{
            address:'JP Street',
            city:'Pune',
            country:'India'
        }
    }

    receiveData(data){
        console.log('Data received is '+data)
    }
}