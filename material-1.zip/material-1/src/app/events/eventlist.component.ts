import { Component } from '@angular/core';

@Component({
    selector:'event-list',
 
    template:`
            <div>
                <h1 [innerText]="eventtitle"></h1>
                <hr/>
                <div>
                    <h2>{{event.name}}</h2>
                    <div>date: {{event.date}}</div>
                    <div>Time: {{event.time}}</div>
                    <div>Price:{{event.price}}</div>
                    <div>
                        <span>Location:{{event.location.address}}</span>
                        <span>{{event.location.city}},{{event.location.country}}</span>
                    </div>
                </div>
            </div>
    `
})
export class EventListComponent{

    eventtitle="Upcoming Angular Events"

    event={
        id:1,
        name:'Angular Connect',
        date:'01/01/2021',
        time:'8:00 am',
        price: 566.50,
        location:{
            address:'JP Street',
            city:'Pune',
            country:'India'
        }
    }
}